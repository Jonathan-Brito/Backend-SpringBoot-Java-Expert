package br.com.brito.user_service_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
